package com.bitemii.service.bitemiiempdet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitemiiempdetApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitemiiempdetApplication.class, args);
	}

}

